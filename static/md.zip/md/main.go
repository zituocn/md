package main

import (
	_ "github.com/zituocn/md/routers"
	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}

